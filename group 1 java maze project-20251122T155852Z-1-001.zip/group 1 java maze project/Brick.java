public class Brick extends MazeItem{
	Brick(String d){
		super(d);
	}
}
	