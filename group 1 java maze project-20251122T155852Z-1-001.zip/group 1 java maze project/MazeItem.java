public class MazeItem{
	String desc;
	String image;

	MazeItem(String d){
		desc=d;
	}
	
}
